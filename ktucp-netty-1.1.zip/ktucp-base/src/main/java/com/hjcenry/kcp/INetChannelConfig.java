package com.hjcenry.kcp;

/**
 * 网络配置接口
 *
 * @author hejincheng
 * @version 1.0
 * @date 2022/1/16 10:03
 **/
public interface INetChannelConfig {
}
