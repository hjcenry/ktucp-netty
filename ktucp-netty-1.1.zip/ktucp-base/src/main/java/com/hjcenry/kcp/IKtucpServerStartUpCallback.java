package com.hjcenry.kcp;

/**
 * 启动完成回调
 *
 * @author hejincheng
 * @version 1.0
 * @date 2022/1/14 18:56
 **/
public interface IKtucpServerStartUpCallback {

    /**
     * 回调
     */
    public void apply();
}
