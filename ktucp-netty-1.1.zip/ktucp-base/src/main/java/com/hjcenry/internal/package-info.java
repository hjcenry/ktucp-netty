/**
 * Internal Utilities
 */
package com.hjcenry.internal;