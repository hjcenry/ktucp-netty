package com.hjcenry.internal;

import java.util.Set;

/**
 * @author <a href="mailto:szhnet@gmail.com">szh</a>
 */
public interface ReItrSet<E> extends Set<E>, ReItrCollection<E> {

}
