package com.hjcenry.codec;

/**
 * 消息编解码接口
 *
 * @author hejincheng
 * @version 1.0
 * @date 2022/1/11 10:31
 */
public interface IMessageCoder {
}
