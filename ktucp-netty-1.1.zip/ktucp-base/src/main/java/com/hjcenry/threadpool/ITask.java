package com.hjcenry.threadpool;

/**
 * Created by JinMiao
 * 2018/5/2.
 */
public interface ITask {

    void execute();
}
