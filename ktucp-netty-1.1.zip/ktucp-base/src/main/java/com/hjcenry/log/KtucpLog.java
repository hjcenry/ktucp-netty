package com.hjcenry.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * log
 *
 * @author hejincheng
 * @version 1.0
 * @date 2022/1/13 17:04
 **/
public class KtucpLog {
    /**
     * KCP log
     */
    public static final Logger logger = LoggerFactory.getLogger(KtucpLog.class);
}
