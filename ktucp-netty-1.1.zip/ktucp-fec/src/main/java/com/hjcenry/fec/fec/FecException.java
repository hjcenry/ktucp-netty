package com.hjcenry.fec.fec;

/**
 * Created by JinMiao
 * 2018/6/8.
 */
public class FecException extends RuntimeException {

    public FecException(String message) {
        super(message);
    }
}
